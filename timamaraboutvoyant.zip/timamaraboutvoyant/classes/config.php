<?php
define("HOST", "localhost");
define("DBNAME", "simple");
define("USER", "root");
define("PASS", "");
define("SALT","Ma clé du bonheur!");
?>