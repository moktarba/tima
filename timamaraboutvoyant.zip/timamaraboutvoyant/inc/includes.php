<?php 
	session_start("connexion");
	include "config.php";
  	include "classes/Db.php";
  	include "classes/Texte.php";
  	include "classes/USER.php";
  	$DB= new Db();

?>